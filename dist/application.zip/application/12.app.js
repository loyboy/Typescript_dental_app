(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[12],{

/***/ "./src/modules/implants/components/implants-details.tsx":
/*!**************************************************************!*\
  !*** ./src/modules/implants/components/implants-details.tsx ***!
  \**************************************************************/
/*! exports provided: ImplantSheetPanel */
/***/ (function(module, exports) {

eval("throw new Error(\"Module parse failed: Unexpected token (77:144)\\nFile was processed with these loaders:\\n * ./node_modules/ts-loader/index.js\\nYou may need an additional loader to handle the result of these loaders.\\n|                     React.createElement(Col, { sm: 6 },\\n|                         React.createElement(\\\"div\\\", { className: \\\"appointment-input units-number\\\" },\\n>                             React.createElement(TextField, { label: text('Bld Time '), name: \\\"diagnosis_lab_bldtime\\\", value: this.props.implant., onChange: (ev, val) => (this.props.implant.diagnosis_lab_bldtime = val), disabled: !this.canEdit }))),\\n|                     React.createElement(Col, { sm: 6 },\\n|                         React.createElement(\\\"div\\\", { className: \\\"appointment-input units-number\\\" },\");\n\n//# sourceURL=webpack:///./src/modules/implants/components/implants-details.tsx?");

/***/ })

}]);